import React from "react";

const CreditRepayPage = () => (
  <div className="min-h-screen bg-white px-6 pt-16">
    <h1 className="text-2xl font-semibold text-slate-900">Credit Repay</h1>
  </div>
);

export default CreditRepayPage;
