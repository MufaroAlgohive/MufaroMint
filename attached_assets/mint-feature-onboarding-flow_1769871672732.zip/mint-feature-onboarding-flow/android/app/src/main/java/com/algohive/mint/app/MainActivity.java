package com.algohive.mint.app;

import com.getcapacitor.BridgeFragmentActivity;

public class MainActivity extends BridgeFragmentActivity {}
